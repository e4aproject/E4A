# API Reference

- `POST /mandates/create` — create a mandate
- `POST /mandates/execute/{id}` — execute a mandate
- `GET /reputation` — fetch aggregated reputation
- `GET /health` — node health
