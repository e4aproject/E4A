# CLI Reference

Use the CLI to create mandates, run governance flows, and inspect reputation.

Examples:

